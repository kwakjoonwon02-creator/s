#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker가 설치되어 있지 않습니다. Docker Engine과 compose plugin을 먼저 설치하세요." >&2
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "docker compose plugin을 찾을 수 없습니다." >&2
  exit 1
fi

if [[ ! -f .env ]]; then
  cp .env.example .env
  DB_SECRET="$(openssl rand -hex 24)"
  JWT_SECRET="$(openssl rand -hex 48)"
  sed -i "s/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=${DB_SECRET}/" .env
  sed -i "s/^JWT_SECRET=.*/JWT_SECRET=${JWT_SECRET}/" .env
  if [[ -n "${1:-}" ]]; then
    sed -i "s/^SITE_DOMAIN=.*/SITE_DOMAIN=${1}/" .env
  else
    sed -i "s/^SITE_DOMAIN=.*/SITE_DOMAIN=/" .env
  fi
  echo ".env를 생성하고 안전한 비밀키를 자동 설정했습니다."
else
  echo "기존 .env를 그대로 사용합니다."
fi

docker compose up -d --build
docker compose ps

echo
echo "EyeOnChess가 실행되었습니다."
if [[ -n "${1:-}" ]]; then
  echo "도메인: http://${1} (HTTPS 발급은 README.md 참고)"
else
  echo "브라우저에서 http://VPS_IP 로 접속하세요."
fi
