#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER_NAME="eyeonchess-cloudflare"
ORIGIN_URL="${ORIGIN_URL:-http://127.0.0.1:80}"
PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
URL_FILE="$PROJECT_DIR/.cloudflare-url"

if ! command -v docker >/dev/null 2>&1; then
  echo "오류: Docker가 설치되어 있지 않습니다." >&2
  exit 1
fi

cd "$PROJECT_DIR"

# Docker 권한이 없으면 sudo를 사용합니다.
if docker info >/dev/null 2>&1; then
  DOCKER=(docker)
elif command -v sudo >/dev/null 2>&1; then
  DOCKER=(sudo docker)
else
  echo "오류: Docker 실행 권한이 없습니다. sudo로 다시 실행하세요." >&2
  exit 1
fi

# 기존 EyeOnChess 서비스가 멈춰 있으면 먼저 올립니다.
if ! curl -fsS --max-time 3 "$ORIGIN_URL/api/health" >/dev/null 2>&1; then
  echo "EyeOnChess 서비스를 시작합니다..."
  if "${DOCKER[@]}" compose version >/dev/null 2>&1; then
    "${DOCKER[@]}" compose up -d
  else
    echo "오류: docker compose를 찾을 수 없습니다." >&2
    exit 1
  fi

  for _ in $(seq 1 45); do
    if curl -fsS --max-time 3 "$ORIGIN_URL/api/health" >/dev/null 2>&1; then
      break
    fi
    sleep 2
  done
fi

if ! curl -fsS --max-time 5 "$ORIGIN_URL/api/health" >/dev/null 2>&1; then
  echo "오류: $ORIGIN_URL 에서 EyeOnChess API가 응답하지 않습니다." >&2
  "${DOCKER[@]}" compose ps || true
  "${DOCKER[@]}" compose logs --tail=100 api nginx || true
  exit 1
fi

"${DOCKER[@]}" rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true

echo "Cloudflare Quick Tunnel을 시작합니다..."
"${DOCKER[@]}" run -d \
  --name "$CONTAINER_NAME" \
  --restart unless-stopped \
  --network host \
  cloudflare/cloudflared:latest \
  tunnel --no-autoupdate --protocol http2 --url "$ORIGIN_URL" >/dev/null

PUBLIC_URL=""
for _ in $(seq 1 30); do
  PUBLIC_URL=$("${DOCKER[@]}" logs "$CONTAINER_NAME" 2>&1 \
    | grep -Eo 'https://[a-z0-9-]+\.trycloudflare\.com' \
    | tail -n 1 || true)
  if [[ -n "$PUBLIC_URL" ]]; then
    break
  fi
  sleep 1
done

if [[ -z "$PUBLIC_URL" ]]; then
  echo "오류: Cloudflare 주소를 받지 못했습니다." >&2
  "${DOCKER[@]}" logs --tail=100 "$CONTAINER_NAME" >&2 || true
  exit 1
fi

printf '%s\n' "$PUBLIC_URL" > "$URL_FILE"

echo
echo "============================================================"
echo "EyeOnChess 공개 HTTPS 주소"
echo "$PUBLIC_URL"
echo "============================================================"
echo
echo "주소 확인: cat $URL_FILE"
echo "로그 확인: ${DOCKER[*]} logs -f $CONTAINER_NAME"
echo "중지:      ${DOCKER[*]} rm -f $CONTAINER_NAME"
echo
echo "주의: Quick Tunnel 주소는 컨테이너를 새로 만들면 바뀔 수 있습니다."
