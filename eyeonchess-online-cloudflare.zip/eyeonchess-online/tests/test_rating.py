from api.app.rating import expected_score, rating_changes


def test_equal_ratings_expected_half():
    assert expected_score(100, 100) == 0.5


def test_equal_ratings_winner_gets_16():
    assert rating_changes(100, 100, "1-0", 32) == (16, -16)


def test_draw_is_zero_for_equal_ratings():
    assert rating_changes(100, 100, "1/2-1/2", 32) == (0, 0)
