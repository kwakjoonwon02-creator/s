#!/bin/sh
set -eu

DOMAIN="${SITE_DOMAIN:-}"
CERT_DIR="/etc/letsencrypt/live/${DOMAIN}"

write_common_locations() {
  cat <<'BLOCK'
    client_max_body_size 2m;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location /api/ {
        proxy_pass http://api:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }

    location /ws {
        proxy_pass http://api:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    location / {
        proxy_pass http://web:80;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
BLOCK
}

{
  echo 'server {'
  echo '    listen 80;'
  echo '    listen [::]:80;'
  echo "    server_name ${DOMAIN:-_};"
  write_common_locations
  echo '}'
} > /etc/nginx/conf.d/default.conf

if [ -n "$DOMAIN" ] && [ -f "$CERT_DIR/fullchain.pem" ] && [ -f "$CERT_DIR/privkey.pem" ]; then
  {
    echo 'server {'
    echo '    listen 80;'
    echo '    listen [::]:80;'
    echo "    server_name $DOMAIN;"
    echo '    location /.well-known/acme-challenge/ { root /var/www/certbot; }'
    echo '    location / { return 301 https://$host$request_uri; }'
    echo '}'
    echo 'server {'
    echo '    listen 443 ssl http2;'
    echo '    listen [::]:443 ssl http2;'
    echo "    server_name $DOMAIN;"
    echo "    ssl_certificate $CERT_DIR/fullchain.pem;"
    echo "    ssl_certificate_key $CERT_DIR/privkey.pem;"
    echo '    ssl_protocols TLSv1.2 TLSv1.3;'
    echo '    ssl_session_cache shared:SSL:10m;'
    echo '    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;'
    write_common_locations
    echo '}'
  } > /etc/nginx/conf.d/default.conf
fi

exec nginx -g 'daemon off;'
