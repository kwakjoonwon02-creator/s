from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./eyeonchess.db")
    jwt_secret: str = os.getenv("JWT_SECRET", "change-me-in-production")
    jwt_issuer: str = os.getenv("JWT_ISSUER", "eyeonchess")
    jwt_days: int = int(os.getenv("JWT_DAYS", "30"))
    google_client_id: str = os.getenv("GOOGLE_CLIENT_ID", "")
    initial_rating: int = int(os.getenv("INITIAL_RATING", "100"))
    rating_k: int = int(os.getenv("RATING_K", "32"))
    game_minutes: int = int(os.getenv("GAME_MINUTES", "10"))
    site_name: str = os.getenv("SITE_NAME", "EyeOnChess")


settings = Settings()
