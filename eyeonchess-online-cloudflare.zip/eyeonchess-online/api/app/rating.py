from __future__ import annotations


def expected_score(player_rating: int, opponent_rating: int) -> float:
    return 1.0 / (1.0 + 10.0 ** ((opponent_rating - player_rating) / 400.0))


def elo_delta(player_rating: int, opponent_rating: int, score: float, k: int = 32) -> int:
    return round(k * (score - expected_score(player_rating, opponent_rating)))


def rating_changes(white_rating: int, black_rating: int, result: str, k: int = 32) -> tuple[int, int]:
    if result == "1-0":
        white_score = 1.0
    elif result == "0-1":
        white_score = 0.0
    elif result == "1/2-1/2":
        white_score = 0.5
    else:
        raise ValueError("지원하지 않는 경기 결과입니다.")

    white_delta = elo_delta(white_rating, black_rating, white_score, k)
    black_delta = elo_delta(black_rating, white_rating, 1.0 - white_score, k)
    return white_delta, black_delta
