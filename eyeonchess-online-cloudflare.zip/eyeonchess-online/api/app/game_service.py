from __future__ import annotations

import json
import random
import string
from datetime import datetime, timezone

import chess
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .models import Game, User
from .rating import rating_changes


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def ensure_aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def random_room_code(length: int = 6) -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(random.choice(alphabet) for _ in range(length))


def unique_room_code(db: Session) -> str:
    for _ in range(30):
        code = random_room_code()
        exists = db.scalar(select(Game.id).where(Game.room_code == code))
        if not exists:
            return code
    raise RuntimeError("방 코드를 만들지 못했습니다.")


def create_game(
    db: Session,
    white_id: str | None,
    black_id: str | None,
    *,
    rated: bool = True,
    room_code: str | None = None,
    waiting: bool = False,
) -> Game:
    initial_ms = settings.game_minutes * 60_000
    now = utcnow()
    game = Game(
        white_id=white_id,
        black_id=black_id,
        room_code=room_code,
        status="waiting" if waiting else "active",
        rated=rated,
        fen=chess.STARTING_FEN,
        moves_uci="[]",
        initial_time_ms=initial_ms,
        white_time_ms=initial_ms,
        black_time_ms=initial_ms,
        started_at=None if waiting else now,
        last_tick_at=None if waiting else now,
    )
    db.add(game)
    db.commit()
    db.refresh(game)
    return game


def start_waiting_game(db: Session, game: Game, joining_user_id: str) -> Game:
    if game.status != "waiting":
        raise ValueError("이미 시작했거나 종료된 방입니다.")
    if joining_user_id in {game.white_id, game.black_id}:
        raise ValueError("자신이 만든 방에는 다시 참가할 수 없습니다.")

    creator_id = game.white_id or game.black_id
    if not creator_id:
        raise ValueError("방 생성자를 찾을 수 없습니다.")

    if random.choice([True, False]):
        game.white_id, game.black_id = creator_id, joining_user_id
    else:
        game.white_id, game.black_id = joining_user_id, creator_id

    now = utcnow()
    game.status = "active"
    game.started_at = now
    game.last_tick_at = now
    game.room_code = None
    db.commit()
    db.refresh(game)
    return game


def board_from_game(game: Game) -> chess.Board:
    return chess.Board(game.fen)


def moves_list(game: Game) -> list[str]:
    try:
        value = json.loads(game.moves_uci or "[]")
        return [str(move) for move in value]
    except json.JSONDecodeError:
        return []


def current_clock_values(game: Game, now: datetime | None = None) -> tuple[int, int]:
    white_ms = game.white_time_ms
    black_ms = game.black_time_ms
    if game.status != "active" or not game.last_tick_at:
        return max(0, white_ms), max(0, black_ms)

    now = now or utcnow()
    last_tick = ensure_aware(game.last_tick_at) or now
    elapsed_ms = max(0, int((now - last_tick).total_seconds() * 1000))
    board = board_from_game(game)
    if board.turn == chess.WHITE:
        white_ms -= elapsed_ms
    else:
        black_ms -= elapsed_ms
    return max(0, white_ms), max(0, black_ms)


def apply_elapsed_clock(game: Game, now: datetime | None = None) -> str | None:
    if game.status != "active" or not game.last_tick_at:
        return None
    now = now or utcnow()
    white_ms, black_ms = current_clock_values(game, now)
    game.white_time_ms = white_ms
    game.black_time_ms = black_ms
    game.last_tick_at = now
    if white_ms <= 0:
        return "white"
    if black_ms <= 0:
        return "black"
    return None


def finish_game(db: Session, game: Game, result: str, reason: str) -> Game:
    if game.status == "finished":
        return game
    if not game.white_id or not game.black_id:
        raise ValueError("양쪽 선수가 없는 경기는 종료할 수 없습니다.")

    white = db.get(User, game.white_id)
    black = db.get(User, game.black_id)
    if not white or not black:
        raise ValueError("선수 계정을 찾을 수 없습니다.")

    game.status = "finished"
    game.result = result
    game.finish_reason = reason
    game.finished_at = utcnow()
    game.last_tick_at = None
    game.draw_offer_by = None
    game.winner_id = white.id if result == "1-0" else black.id if result == "0-1" else None

    white.games_played += 1
    black.games_played += 1
    if result == "1-0":
        white.wins += 1
        black.losses += 1
    elif result == "0-1":
        black.wins += 1
        white.losses += 1
    else:
        white.draws += 1
        black.draws += 1

    game.white_rating_before = white.rating
    game.black_rating_before = black.rating
    if game.rated:
        white_delta, black_delta = rating_changes(white.rating, black.rating, result, settings.rating_k)
        white.rating = max(0, white.rating + white_delta)
        black.rating = max(0, black.rating + black_delta)
        game.white_rating_delta = white.rating - game.white_rating_before
        game.black_rating_delta = black.rating - game.black_rating_before
    else:
        game.white_rating_delta = 0
        game.black_rating_delta = 0

    db.commit()
    db.refresh(game)
    return game


def move_piece(db: Session, game: Game, user_id: str, uci: str) -> Game:
    if game.status != "active":
        raise ValueError("진행 중인 대국이 아닙니다.")

    board = board_from_game(game)
    expected_user = game.white_id if board.turn == chess.WHITE else game.black_id
    if expected_user != user_id:
        raise ValueError("현재 차례가 아닙니다.")

    flagged = apply_elapsed_clock(game)
    if flagged == "white":
        return finish_game(db, game, "0-1", "timeout")
    if flagged == "black":
        return finish_game(db, game, "1-0", "timeout")

    try:
        move = chess.Move.from_uci(uci.lower())
    except ValueError as exc:
        raise ValueError("수 형식이 올바르지 않습니다.") from exc
    if move not in board.legal_moves:
        raise ValueError("둘 수 없는 수입니다.")

    board.push(move)
    history = moves_list(game)
    history.append(move.uci())
    game.moves_uci = json.dumps(history)
    game.last_move_uci = move.uci()
    game.fen = board.fen()
    game.draw_offer_by = None
    game.last_tick_at = utcnow()

    outcome = board.outcome(claim_draw=True)
    if outcome:
        if outcome.winner is chess.WHITE:
            result = "1-0"
        elif outcome.winner is chess.BLACK:
            result = "0-1"
        else:
            result = "1/2-1/2"
        return finish_game(db, game, result, outcome.termination.name.lower())

    db.commit()
    db.refresh(game)
    return game


def resign(db: Session, game: Game, user_id: str) -> Game:
    if game.status != "active":
        raise ValueError("진행 중인 대국이 아닙니다.")
    if user_id == game.white_id:
        return finish_game(db, game, "0-1", "resignation")
    if user_id == game.black_id:
        return finish_game(db, game, "1-0", "resignation")
    raise ValueError("이 대국의 선수가 아닙니다.")


def offer_draw(db: Session, game: Game, user_id: str) -> Game:
    if game.status != "active" or user_id not in {game.white_id, game.black_id}:
        raise ValueError("무승부를 제안할 수 없습니다.")
    game.draw_offer_by = user_id
    db.commit()
    db.refresh(game)
    return game


def accept_draw(db: Session, game: Game, user_id: str) -> Game:
    if game.status != "active":
        raise ValueError("진행 중인 대국이 아닙니다.")
    if not game.draw_offer_by or game.draw_offer_by == user_id:
        raise ValueError("상대의 무승부 제안이 없습니다.")
    if user_id not in {game.white_id, game.black_id}:
        raise ValueError("이 대국의 선수가 아닙니다.")
    return finish_game(db, game, "1/2-1/2", "draw_agreement")


def game_payload(game: Game, viewer_id: str | None = None) -> dict:
    white_ms, black_ms = current_clock_values(game)
    board = board_from_game(game)
    legal_moves: list[str] = []
    current_id = game.white_id if board.turn == chess.WHITE else game.black_id
    if viewer_id and viewer_id == current_id and game.status == "active":
        legal_moves = [move.uci() for move in board.legal_moves]

    return {
        "id": game.id,
        "status": game.status,
        "rated": game.rated,
        "room_code": game.room_code,
        "fen": game.fen,
        "last_move": game.last_move_uci,
        "moves": moves_list(game),
        "turn": "white" if board.turn == chess.WHITE else "black",
        "white": public_user_payload(game.white) if game.white else None,
        "black": public_user_payload(game.black) if game.black else None,
        "viewer_color": "white" if viewer_id == game.white_id else "black" if viewer_id == game.black_id else "spectator",
        "legal_moves": legal_moves,
        "white_time_ms": white_ms,
        "black_time_ms": black_ms,
        "initial_time_ms": game.initial_time_ms,
        "server_time": utcnow().isoformat(),
        "last_tick_at": ensure_aware(game.last_tick_at).isoformat() if game.last_tick_at else None,
        "draw_offer_by": game.draw_offer_by,
        "result": game.result,
        "finish_reason": game.finish_reason,
        "white_rating_delta": game.white_rating_delta,
        "black_rating_delta": game.black_rating_delta,
    }


def public_user_payload(user: User) -> dict:
    return {
        "id": user.id,
        "username": user.username,
        "avatar_url": user.avatar_url,
        "is_guest": user.is_guest,
        "rating": user.rating,
        "games_played": user.games_played,
        "wins": user.wins,
        "draws": user.draws,
        "losses": user.losses,
    }


def user_payload(user: User) -> dict:
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "avatar_url": user.avatar_url,
        "is_guest": user.is_guest,
        "rating": user.rating,
        "games_played": user.games_played,
        "wins": user.wins,
        "draws": user.draws,
        "losses": user.losses,
    }
