from __future__ import annotations

import asyncio
import random
import re
import secrets
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

import jwt
from fastapi import Depends, FastAPI, Header, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token as google_id_token
from pydantic import BaseModel
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from .config import settings
from .database import Base, SessionLocal, engine
from .game_service import (
    accept_draw,
    apply_elapsed_clock,
    create_game,
    finish_game,
    game_payload,
    offer_draw,
    resign,
    start_waiting_game,
    unique_room_code,
    user_payload,
    move_piece,
)
from .models import Game, User, utcnow
from .security import create_access_token, decode_access_token, hash_password, verify_password


USERNAME_RE = re.compile(r"^[0-9A-Za-z가-힣_\-]{2,24}$")


class RegisterBody(BaseModel):
    email: str
    username: str
    password: str


class LoginBody(BaseModel):
    email: str
    password: str


class GoogleBody(BaseModel):
    credential: str


class ProfileBody(BaseModel):
    username: str


class RoomBody(BaseModel):
    rated: bool = True


class ConnectionManager:
    def __init__(self) -> None:
        self.connections: dict[str, set[WebSocket]] = defaultdict(set)
        self.queue: list[str] = []
        self.queue_lock = asyncio.Lock()
        self.game_locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self.active_games: set[str] = set()

    async def connect(self, user_id: str, websocket: WebSocket) -> None:
        await websocket.accept()
        self.connections[user_id].add(websocket)

    def disconnect(self, user_id: str, websocket: WebSocket) -> None:
        sockets = self.connections.get(user_id)
        if sockets:
            sockets.discard(websocket)
            if not sockets:
                self.connections.pop(user_id, None)
        if user_id in self.queue:
            self.queue = [queued for queued in self.queue if queued != user_id]

    async def send_user(self, user_id: str, message: dict[str, Any]) -> None:
        dead: list[WebSocket] = []
        for websocket in list(self.connections.get(user_id, set())):
            try:
                await websocket.send_json(message)
            except Exception:
                dead.append(websocket)
        for websocket in dead:
            self.disconnect(user_id, websocket)

    async def broadcast_game(self, game: Game) -> None:
        for user_id in filter(None, [game.white_id, game.black_id]):
            with SessionLocal() as db:
                fresh = db.get(Game, game.id)
                if fresh:
                    await self.send_user(user_id, {"type": "game_state", "game": game_payload(fresh, user_id)})


manager = ConnectionManager()


def normalize_email(email: str) -> str:
    value = email.strip().lower()
    if "@" not in value or len(value) > 320:
        raise HTTPException(400, "이메일 형식이 올바르지 않습니다.")
    return value


def normalize_username(username: str) -> str:
    value = username.strip()
    if not USERNAME_RE.fullmatch(value):
        raise HTTPException(400, "닉네임은 2~24자의 한글, 영문, 숫자, _, -만 사용할 수 있습니다.")
    return value


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def bearer_token(authorization: str | None) -> str | None:
    if not authorization:
        return None
    prefix, _, token = authorization.partition(" ")
    return token if prefix.lower() == "bearer" and token else None


def optional_user(
    authorization: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> User | None:
    token = bearer_token(authorization)
    if not token:
        return None
    try:
        user_id = decode_access_token(token)
    except jwt.InvalidTokenError:
        return None
    return db.get(User, user_id)


def current_user(user: User | None = Depends(optional_user)) -> User:
    if not user:
        raise HTTPException(401, "로그인이 필요합니다.")
    return user


def auth_response(user: User) -> dict:
    return {"token": create_access_token(user.id), "user": user_payload(user)}


async def clock_sweeper() -> None:
    while True:
        await asyncio.sleep(1)
        game_ids = list(manager.active_games)
        for game_id in game_ids:
            lock = manager.game_locks[game_id]
            if lock.locked():
                continue
            async with lock:
                with SessionLocal() as db:
                    game = db.get(Game, game_id)
                    if not game or game.status != "active":
                        manager.active_games.discard(game_id)
                        continue
                    flagged = apply_elapsed_clock(game)
                    if flagged == "white":
                        game = finish_game(db, game, "0-1", "timeout")
                        manager.active_games.discard(game_id)
                        await manager.broadcast_game(game)
                    elif flagged == "black":
                        game = finish_game(db, game, "1-0", "timeout")
                        manager.active_games.discard(game_id)
                        await manager.broadcast_game(game)
                    else:
                        db.rollback()


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    task = asyncio.create_task(clock_sweeper())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="EyeOnChess API", lifespan=lifespan)


@app.exception_handler(ValueError)
async def value_error_handler(_, exc: ValueError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.get("/api/health")
def health() -> dict:
    return {"ok": True, "service": settings.site_name}


@app.get("/api/config")
def public_config() -> dict:
    return {
        "site_name": settings.site_name,
        "google_client_id": settings.google_client_id,
        "initial_rating": settings.initial_rating,
        "game_minutes": settings.game_minutes,
    }


@app.post("/api/auth/guest")
def create_guest(db: Session = Depends(get_db)) -> dict:
    suffix = secrets.token_hex(3).upper()
    user = User(username=f"Guest-{suffix}", is_guest=True, rating=settings.initial_rating)
    db.add(user)
    db.commit()
    db.refresh(user)
    return auth_response(user)


@app.post("/api/auth/register")
def register(
    body: RegisterBody,
    db: Session = Depends(get_db),
    user: User | None = Depends(optional_user),
) -> dict:
    email = normalize_email(body.email)
    username = normalize_username(body.username)
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "이미 가입된 이메일입니다.")
    if db.scalar(select(User.id).where(User.username == username, User.id != (user.id if user else ""))):
        raise HTTPException(409, "이미 사용 중인 닉네임입니다.")

    try:
        password_hash = hash_password(body.password)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    if user and user.is_guest:
        user.email = email
        user.username = username
        user.password_hash = password_hash
        user.is_guest = False
    else:
        user = User(
            email=email,
            username=username,
            password_hash=password_hash,
            is_guest=False,
            rating=settings.initial_rating,
        )
        db.add(user)
    db.commit()
    db.refresh(user)
    return auth_response(user)


@app.post("/api/auth/login")
def login(body: LoginBody, db: Session = Depends(get_db)) -> dict:
    email = normalize_email(body.email)
    user = db.scalar(select(User).where(User.email == email))
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "이메일 또는 비밀번호가 맞지 않습니다.")
    user.last_seen_at = utcnow()
    db.commit()
    return auth_response(user)


@app.post("/api/auth/google")
def google_login(
    body: GoogleBody,
    db: Session = Depends(get_db),
    user: User | None = Depends(optional_user),
) -> dict:
    if not settings.google_client_id:
        raise HTTPException(503, "Google 로그인이 설정되지 않았습니다.")
    try:
        claims = google_id_token.verify_oauth2_token(
            body.credential,
            google_requests.Request(),
            settings.google_client_id,
        )
    except Exception as exc:
        raise HTTPException(401, "Google 인증을 확인하지 못했습니다.") from exc

    google_sub = str(claims.get("sub", ""))
    email = str(claims.get("email", "")).lower() or None
    if not google_sub:
        raise HTTPException(401, "Google 계정 식별자가 없습니다.")

    google_conditions = [User.google_sub == google_sub]
    if email:
        google_conditions.append(User.email == email)
    existing = db.scalar(select(User).where(or_(*google_conditions)))
    if existing:
        existing.google_sub = google_sub
        existing.avatar_url = str(claims.get("picture", "")) or existing.avatar_url
        existing.last_seen_at = utcnow()
        db.commit()
        db.refresh(existing)
        return auth_response(existing)

    suggested = str(claims.get("name", "Player")).replace(" ", "")[:18] or "Player"
    suggested = re.sub(r"[^0-9A-Za-z가-힣_\-]", "", suggested) or "Player"
    candidate = suggested
    while db.scalar(select(User.id).where(User.username == candidate)):
        candidate = f"{suggested[:15]}-{secrets.token_hex(2)}"

    if user and user.is_guest:
        user.email = email
        user.username = candidate
        user.google_sub = google_sub
        user.avatar_url = str(claims.get("picture", "")) or None
        user.is_guest = False
    else:
        user = User(
            email=email,
            username=candidate,
            google_sub=google_sub,
            avatar_url=str(claims.get("picture", "")) or None,
            is_guest=False,
            rating=settings.initial_rating,
        )
        db.add(user)
    db.commit()
    db.refresh(user)
    return auth_response(user)


@app.get("/api/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    user.last_seen_at = utcnow()
    db.commit()
    return user_payload(user)


@app.patch("/api/me")
def update_profile(body: ProfileBody, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    username = normalize_username(body.username)
    duplicate = db.scalar(select(User.id).where(User.username == username, User.id != user.id))
    if duplicate:
        raise HTTPException(409, "이미 사용 중인 닉네임입니다.")
    user.username = username
    db.commit()
    db.refresh(user)
    return user_payload(user)


@app.get("/api/leaderboard")
def leaderboard(db: Session = Depends(get_db)) -> dict:
    users = db.scalars(
        select(User).where(User.games_played > 0).order_by(User.rating.desc(), User.games_played.desc()).limit(50)
    ).all()
    return {"players": [user_payload(user) for user in users]}


@app.get("/api/games/active")
def active_game(user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    game = db.scalar(
        select(Game)
        .where(
            Game.status.in_(["waiting", "active"]),
            or_(Game.white_id == user.id, Game.black_id == user.id),
        )
        .order_by(Game.created_at.desc())
    )
    if not game:
        return {"game": None}
    if game.status == "active":
        manager.active_games.add(game.id)
    return {"game": game_payload(game, user.id)}


@app.get("/api/games/{game_id}")
def read_game(game_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    game = db.get(Game, game_id)
    if not game:
        raise HTTPException(404, "대국을 찾을 수 없습니다.")
    if user.id not in {game.white_id, game.black_id}:
        raise HTTPException(403, "이 대국을 볼 권한이 없습니다.")
    if game.status == "active":
        manager.active_games.add(game.id)
    return {"game": game_payload(game, user.id)}


@app.post("/api/rooms")
def create_room(body: RoomBody, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    existing = db.scalar(
        select(Game).where(Game.status.in_(["waiting", "active"]), or_(Game.white_id == user.id, Game.black_id == user.id))
    )
    if existing:
        raise HTTPException(409, "이미 대기 중이거나 진행 중인 대국이 있습니다.")
    code = unique_room_code(db)
    game = create_game(db, user.id, None, rated=body.rated, room_code=code, waiting=True)
    return {"game": game_payload(game, user.id), "room_code": code}


@app.post("/api/rooms/{code}/join")
async def join_room(code: str, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    active = db.scalar(
        select(Game).where(
            Game.status.in_(["waiting", "active"]),
            or_(Game.white_id == user.id, Game.black_id == user.id),
        )
    )
    if active:
        raise HTTPException(409, "이미 대기 중이거나 진행 중인 대국이 있습니다.")
    code = code.strip().upper()
    game = db.scalar(select(Game).where(Game.room_code == code, Game.status == "waiting"))
    if not game:
        raise HTTPException(404, "참가 가능한 방을 찾지 못했습니다.")
    game = start_waiting_game(db, game, user.id)
    manager.active_games.add(game.id)
    await manager.broadcast_game(game)
    for player_id in [game.white_id, game.black_id]:
        if player_id:
            await manager.send_user(player_id, {"type": "match_found", "game_id": game.id})
    return {"game": game_payload(game, user.id)}


@app.delete("/api/rooms/{game_id}")
def cancel_room(game_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    game = db.get(Game, game_id)
    if not game or game.status != "waiting" or user.id not in {game.white_id, game.black_id}:
        raise HTTPException(404, "취소할 대기 방을 찾을 수 없습니다.")
    db.delete(game)
    db.commit()
    return {"ok": True}


async def handle_queue_join(user_id: str) -> None:
    async with manager.queue_lock:
        with SessionLocal() as db:
            existing = db.scalar(
                select(Game).where(
                    Game.status.in_(["waiting", "active"]),
                    or_(Game.white_id == user_id, Game.black_id == user_id),
                )
            )
            if existing:
                await manager.send_user(user_id, {"type": "error", "message": "이미 대기 중이거나 진행 중인 대국이 있습니다."})
                return

            manager.queue = [queued for queued in manager.queue if queued != user_id]
            current = db.get(User, user_id)
            opponent_id = None
            best_index = None
            best_gap = None
            for index, candidate_id in enumerate(manager.queue):
                if candidate_id == user_id or candidate_id not in manager.connections:
                    continue
                candidate_active = db.scalar(
                    select(Game.id).where(
                        Game.status.in_(["waiting", "active"]),
                        or_(Game.white_id == candidate_id, Game.black_id == candidate_id),
                    )
                )
                if candidate_active:
                    continue
                candidate = db.get(User, candidate_id)
                if not candidate or not current:
                    continue
                gap = abs(candidate.rating - current.rating)
                if best_gap is None or gap < best_gap:
                    best_gap = gap
                    best_index = index
                    opponent_id = candidate_id

            if best_index is not None:
                manager.queue.pop(best_index)
            manager.queue = [queued for queued in manager.queue if queued in manager.connections]

            if not opponent_id:
                manager.queue.append(user_id)
                await manager.send_user(user_id, {"type": "queue_status", "status": "waiting"})
                return

            if random.choice([True, False]):
                white_id, black_id = user_id, opponent_id
            else:
                white_id, black_id = opponent_id, user_id
            game = create_game(db, white_id, black_id, rated=True)
            manager.active_games.add(game.id)

        for player_id in [white_id, black_id]:
            await manager.send_user(player_id, {"type": "queue_status", "status": "matched"})
            await manager.send_user(player_id, {"type": "match_found", "game_id": game.id})
        await manager.broadcast_game(game)


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    token = websocket.query_params.get("token", "")
    try:
        user_id = decode_access_token(token)
    except jwt.InvalidTokenError:
        await websocket.close(code=4401)
        return

    with SessionLocal() as db:
        user = db.get(User, user_id)
        if not user:
            await websocket.close(code=4401)
            return

    await manager.connect(user_id, websocket)
    await manager.send_user(user_id, {"type": "hello", "user_id": user_id})

    try:
        while True:
            message = await websocket.receive_json()
            action = str(message.get("type", ""))

            if action == "ping":
                await websocket.send_json({"type": "pong", "at": datetime.now(timezone.utc).isoformat()})
            elif action == "queue_join":
                await handle_queue_join(user_id)
            elif action == "queue_leave":
                async with manager.queue_lock:
                    manager.queue = [queued for queued in manager.queue if queued != user_id]
                await manager.send_user(user_id, {"type": "queue_status", "status": "idle"})
            elif action == "game_subscribe":
                game_id = str(message.get("game_id", ""))
                with SessionLocal() as db:
                    game = db.get(Game, game_id)
                    if not game or user_id not in {game.white_id, game.black_id}:
                        await websocket.send_json({"type": "error", "message": "대국을 찾을 수 없습니다."})
                    else:
                        if game.status == "active":
                            manager.active_games.add(game.id)
                        await websocket.send_json({"type": "game_state", "game": game_payload(game, user_id)})
            elif action in {"move", "resign", "draw_offer", "draw_accept"}:
                game_id = str(message.get("game_id", ""))
                async with manager.game_locks[game_id]:
                    with SessionLocal() as db:
                        game = db.get(Game, game_id)
                        if not game or user_id not in {game.white_id, game.black_id}:
                            await websocket.send_json({"type": "error", "message": "대국을 찾을 수 없습니다."})
                            continue
                        try:
                            if action == "move":
                                game = move_piece(db, game, user_id, str(message.get("uci", "")))
                            elif action == "resign":
                                game = resign(db, game, user_id)
                            elif action == "draw_offer":
                                game = offer_draw(db, game, user_id)
                            else:
                                game = accept_draw(db, game, user_id)
                        except ValueError as exc:
                            await websocket.send_json({"type": "error", "message": str(exc)})
                            continue
                        if game.status == "finished":
                            manager.active_games.discard(game.id)
                        else:
                            manager.active_games.add(game.id)
                    await manager.broadcast_game(game)
            else:
                await websocket.send_json({"type": "error", "message": "알 수 없는 요청입니다."})
    except WebSocketDisconnect:
        manager.disconnect(user_id, websocket)
    except Exception:
        manager.disconnect(user_id, websocket)
        try:
            await websocket.close(code=1011)
        except Exception:
            pass
