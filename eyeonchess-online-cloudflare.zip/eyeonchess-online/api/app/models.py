from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .config import settings
from .database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def uuid4_str() -> str:
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid4_str)
    email: Mapped[str | None] = mapped_column(String(320), unique=True, nullable=True, index=True)
    username: Mapped[str] = mapped_column(String(24), index=True)
    password_hash: Mapped[str | None] = mapped_column(Text, nullable=True)
    google_sub: Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True, index=True)
    avatar_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_guest: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    rating: Mapped[int] = mapped_column(Integer, default=settings.initial_rating, nullable=False, index=True)
    games_played: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    wins: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    draws: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    losses: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class Game(Base):
    __tablename__ = "games"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid4_str)
    room_code: Mapped[str | None] = mapped_column(String(8), unique=True, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(16), default="waiting", nullable=False, index=True)
    rated: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    white_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    black_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    white: Mapped[User | None] = relationship(foreign_keys=[white_id])
    black: Mapped[User | None] = relationship(foreign_keys=[black_id])

    fen: Mapped[str] = mapped_column(Text, default="startpos", nullable=False)
    moves_uci: Mapped[str] = mapped_column(Text, default="[]", nullable=False)
    last_move_uci: Mapped[str | None] = mapped_column(String(8), nullable=True)

    result: Mapped[str | None] = mapped_column(String(8), nullable=True)
    finish_reason: Mapped[str | None] = mapped_column(String(32), nullable=True)
    winner_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    white_rating_before: Mapped[int | None] = mapped_column(Integer, nullable=True)
    black_rating_before: Mapped[int | None] = mapped_column(Integer, nullable=True)
    white_rating_delta: Mapped[int | None] = mapped_column(Integer, nullable=True)
    black_rating_delta: Mapped[int | None] = mapped_column(Integer, nullable=True)

    initial_time_ms: Mapped[int] = mapped_column(Integer, default=lambda: settings.game_minutes * 60_000, nullable=False)
    white_time_ms: Mapped[int] = mapped_column(Integer, default=lambda: settings.game_minutes * 60_000, nullable=False)
    black_time_ms: Mapped[int] = mapped_column(Integer, default=lambda: settings.game_minutes * 60_000, nullable=False)
    last_tick_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    draw_offer_by: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)
