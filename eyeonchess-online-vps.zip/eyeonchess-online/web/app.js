const TOKEN_KEY = "eyeonchess_token";
const PIECES = {
  K: "♔", Q: "♕", R: "♖", B: "♗", N: "♘", P: "♙",
  k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟",
};

const state = {
  token: localStorage.getItem(TOKEN_KEY),
  user: null,
  config: null,
  socket: null,
  reconnectTimer: null,
  currentGame: null,
  selectedSquare: null,
  pendingPromotion: null,
  clockSnapshotAt: 0,
  queueStartedAt: 0,
  queueTimer: null,
  currentView: "home",
  lastFinishedGameId: null,
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const response = await fetch(path, { ...options, headers });
  let payload = null;
  try { payload = await response.json(); } catch { payload = {}; }
  if (!response.ok) {
    const error = new Error(payload.detail || "요청을 처리하지 못했습니다.");
    error.status = response.status;
    throw error;
  }
  return payload;
}

function setToken(token) {
  state.token = token;
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

function toast(message, type = "info") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  $("#toastStack").appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function showModal(id) { $(id.startsWith("#") ? id : `#${id}`).classList.remove("hidden"); }
function hideModal(id) { $(id.startsWith("#") ? id : `#${id}`).classList.add("hidden"); }

function avatarStyle(el, user) {
  if (!el || !user) return;
  el.textContent = user.username?.slice(0, 1).toUpperCase() || "?";
  if (user.avatar_url) {
    el.style.backgroundImage = `url("${user.avatar_url.replaceAll('"', "")}")`;
    el.textContent = "";
  } else {
    el.style.backgroundImage = "";
  }
}

function tierFor(rating) {
  if (rating >= 1200) return "MASTER";
  if (rating >= 800) return "DIAMOND";
  if (rating >= 500) return "GOLD";
  if (rating >= 250) return "SILVER";
  return "STARTER";
}

function renderUser() {
  const user = state.user;
  if (!user) return;
  $("#chipName").textContent = user.username;
  $("#chipRating").textContent = user.rating;
  avatarStyle($("#chipAvatar"), user);
  $("#homeRating").textContent = user.rating;
  $("#homeTier").textContent = tierFor(user.rating);
  $("#homeGames").textContent = user.games_played;
  const winRate = user.games_played ? Math.round((user.wins / user.games_played) * 100) : 0;
  $("#homeWinRate").textContent = `${winRate}%`;
  $("#homeRecord").textContent = `${user.wins}W · ${user.draws}D · ${user.losses}L`;

  $("#profileName").textContent = user.username;
  $("#profileRating").textContent = user.rating;
  $("#profileGames").textContent = user.games_played;
  $("#profileWins").textContent = user.wins;
  $("#profileDraws").textContent = user.draws;
  $("#profileLosses").textContent = user.losses;
  $("#usernameInput").value = user.username;
  avatarStyle($("#profileAvatar"), user);
  $("#accountBadge").textContent = user.is_guest ? "GUEST ACCOUNT" : "CONNECTED ACCOUNT";
  $("#profileEmail").textContent = user.email || (user.is_guest ? "기록을 영구 보관하려면 계정을 연결하세요." : "Google 계정으로 연결됨");
  $("#accountConnectBox").classList.toggle("hidden", !user.is_guest);
}

async function ensureSession() {
  state.config = await api("/api/config", { headers: {} });
  if (state.token) {
    try {
      state.user = await api("/api/me");
    } catch (error) {
      if (error.status === 401) setToken(null);
    }
  }
  if (!state.user) {
    const data = await api("/api/auth/guest", { method: "POST", headers: {} });
    setToken(data.token);
    state.user = data.user;
  }
  renderUser();
  setupGoogleLogin();
}

async function refreshMe() {
  try {
    state.user = await api("/api/me");
    renderUser();
  } catch (error) {
    console.error(error);
  }
}

function connectSocket() {
  if (!state.token) return;
  clearTimeout(state.reconnectTimer);
  if (state.socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(state.socket.readyState)) return;
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  state.socket = new WebSocket(`${protocol}//${location.host}/ws?token=${encodeURIComponent(state.token)}`);

  state.socket.addEventListener("open", () => {
    if (state.currentGame?.id) sendSocket({ type: "game_subscribe", game_id: state.currentGame.id });
  });
  state.socket.addEventListener("message", (event) => {
    let message;
    try { message = JSON.parse(event.data); } catch { return; }
    handleSocketMessage(message);
  });
  state.socket.addEventListener("close", () => {
    state.reconnectTimer = setTimeout(connectSocket, 1800);
  });
  state.socket.addEventListener("error", () => state.socket?.close());
}

function sendSocket(message) {
  if (state.socket?.readyState !== WebSocket.OPEN) {
    toast("실시간 서버에 다시 연결 중입니다.", "error");
    connectSocket();
    return false;
  }
  state.socket.send(JSON.stringify(message));
  return true;
}

function handleSocketMessage(message) {
  if (message.type === "error") {
    toast(message.message, "error");
  } else if (message.type === "queue_status") {
    if (message.status === "waiting") startQueueUI();
    if (message.status === "idle") stopQueueUI();
  } else if (message.type === "match_found") {
    stopQueueUI();
    hideModal("roomWaitingModal");
    openGame(message.game_id);
  } else if (message.type === "game_state") {
    setGame(message.game);
  }
}

function navigate(view) {
  state.currentView = view;
  $$(".view").forEach((el) => el.classList.remove("active"));
  $$(".nav-link").forEach((el) => el.classList.toggle("active", el.dataset.nav === view));
  const target = view === "ranking" ? "rankingView" : view === "profile" ? "profileView" : view === "game" ? "gameView" : "homeView";
  $(`#${target}`).classList.add("active");
  if (view === "ranking") loadRanking();
  if (view === "profile") renderUser();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function startQueueUI() {
  state.queueStartedAt = Date.now();
  $("#matchmaking").classList.remove("hidden");
  clearInterval(state.queueTimer);
  state.queueTimer = setInterval(() => {
    const seconds = Math.floor((Date.now() - state.queueStartedAt) / 1000);
    $("#queueTimer").textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }, 250);
}

function stopQueueUI() {
  $("#matchmaking").classList.add("hidden");
  clearInterval(state.queueTimer);
  state.queueTimer = null;
}

async function startQuickMatch() {
  const active = await api("/api/games/active");
  if (active.game) {
    if (active.game.status === "waiting") {
      state.currentGame = active.game;
      $("#roomCodeDisplay").textContent = active.game.room_code;
      showModal("roomWaitingModal");
    } else {
      setGame(active.game);
      navigate("game");
    }
    return;
  }
  if (sendSocket({ type: "queue_join" })) startQueueUI();
}

async function openGame(gameId) {
  try {
    const data = await api(`/api/games/${gameId}`);
    setGame(data.game);
    navigate("game");
  } catch (error) {
    toast(error.message, "error");
  }
}

function setGame(game) {
  const wasFinished = state.currentGame?.status !== "finished" && game.status === "finished";
  state.currentGame = game;
  state.selectedSquare = null;
  state.clockSnapshotAt = performance.now();
  if (game.status === "waiting") {
    $("#roomCodeDisplay").textContent = game.room_code || "------";
    showModal("roomWaitingModal");
    return;
  }
  hideModal("roomWaitingModal");
  navigate("game");
  renderGame();
  if (wasFinished && state.lastFinishedGameId !== game.id) {
    state.lastFinishedGameId = game.id;
    refreshMe();
  }
}

function parseFen(fen) {
  const board = {};
  const boardPart = fen.split(" ")[0];
  boardPart.split("/").forEach((row, rowIndex) => {
    let file = 0;
    for (const char of row) {
      if (/\d/.test(char)) {
        file += Number(char);
      } else {
        const square = `${"abcdefgh"[file]}${8 - rowIndex}`;
        board[square] = char;
        file += 1;
      }
    }
  });
  return board;
}

function squareColor(square) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]) - 1;
  return (file + rank) % 2 === 1 ? "light" : "dark";
}

function displaySquares(orientation) {
  const files = orientation === "black" ? [..."hgfedcba"] : [..."abcdefgh"];
  const ranks = orientation === "black" ? [1,2,3,4,5,6,7,8] : [8,7,6,5,4,3,2,1];
  return ranks.flatMap((rank) => files.map((file) => `${file}${rank}`));
}

function isOwnPiece(piece, color) {
  if (!piece || !["white", "black"].includes(color)) return false;
  return color === "white" ? piece === piece.toUpperCase() : piece === piece.toLowerCase();
}

function legalDestinations(from) {
  return (state.currentGame?.legal_moves || []).filter((move) => move.slice(0, 2) === from).map((move) => move.slice(2, 4));
}

function renderBoard() {
  const game = state.currentGame;
  if (!game) return;
  const board = parseFen(game.fen);
  const orientation = game.viewer_color === "black" ? "black" : "white";
  const squares = displaySquares(orientation);
  const legal = new Set(state.selectedSquare ? legalDestinations(state.selectedSquare) : []);
  const lastSquares = new Set(game.last_move ? [game.last_move.slice(0,2), game.last_move.slice(2,4)] : []);
  const chessboard = $("#chessboard");
  chessboard.innerHTML = "";

  for (const square of squares) {
    const squareEl = document.createElement("div");
    squareEl.className = `square ${squareColor(square)}`;
    squareEl.dataset.square = square;
    if (lastSquares.has(square)) squareEl.classList.add("last");
    if (square === state.selectedSquare) squareEl.classList.add("selected");
    if (legal.has(square)) squareEl.classList.add(board[square] ? "capture" : "legal");
    squareEl.addEventListener("click", () => handleSquareClick(square));
    squareEl.addEventListener("dragover", (event) => event.preventDefault());
    squareEl.addEventListener("drop", (event) => {
      event.preventDefault();
      const from = event.dataTransfer.getData("text/plain");
      if (from) tryMove(from, square);
    });

    const piece = board[square];
    if (piece) {
      const pieceEl = document.createElement("span");
      pieceEl.className = `piece ${piece === piece.toUpperCase() ? "white" : "black"}`;
      pieceEl.textContent = PIECES[piece];
      pieceEl.draggable = isOwnPiece(piece, game.viewer_color) && game.status === "active";
      pieceEl.addEventListener("dragstart", (event) => {
        state.selectedSquare = square;
        event.dataTransfer.setData("text/plain", square);
        event.dataTransfer.effectAllowed = "move";
        setTimeout(renderBoard, 0);
      });
      squareEl.appendChild(pieceEl);
    }
    chessboard.appendChild(squareEl);
  }

  const files = orientation === "black" ? "hgfedcba" : "abcdefgh";
  const ranks = orientation === "black" ? "12345678" : "87654321";
  $("#fileLabels").innerHTML = [...files].map((x) => `<span>${x}</span>`).join("");
  $("#rankLabels").innerHTML = [...ranks].map((x) => `<span>${x}</span>`).join("");
}

function handleSquareClick(square) {
  const game = state.currentGame;
  if (!game || game.status !== "active" || game.viewer_color === "spectator") return;
  const board = parseFen(game.fen);
  const piece = board[square];
  if (!state.selectedSquare) {
    if (isOwnPiece(piece, game.viewer_color) && legalDestinations(square).length) {
      state.selectedSquare = square;
      renderBoard();
    }
    return;
  }
  if (state.selectedSquare === square) {
    state.selectedSquare = null;
    renderBoard();
    return;
  }
  if (isOwnPiece(piece, game.viewer_color)) {
    state.selectedSquare = square;
    renderBoard();
    return;
  }
  tryMove(state.selectedSquare, square);
}

function tryMove(from, to) {
  const candidates = (state.currentGame?.legal_moves || []).filter((move) => move.slice(0, 4) === `${from}${to}`);
  if (!candidates.length) {
    state.selectedSquare = null;
    renderBoard();
    return;
  }
  if (candidates.length > 1 || candidates[0].length === 5) {
    openPromotion(candidates);
    return;
  }
  sendMove(candidates[0]);
}

function openPromotion(candidates) {
  state.pendingPromotion = candidates;
  const symbols = state.currentGame.viewer_color === "white" ? { q:"♕", r:"♖", b:"♗", n:"♘" } : { q:"♛", r:"♜", b:"♝", n:"♞" };
  $("#promotionOptions").innerHTML = "";
  for (const promotion of ["q","r","b","n"]) {
    const move = candidates.find((candidate) => candidate.endsWith(promotion));
    if (!move) continue;
    const button = document.createElement("button");
    button.textContent = symbols[promotion];
    button.addEventListener("click", () => {
      hideModal("promotionModal");
      sendMove(move);
    });
    $("#promotionOptions").appendChild(button);
  }
  showModal("promotionModal");
}

function sendMove(uci) {
  state.selectedSquare = null;
  renderBoard();
  sendSocket({ type: "move", game_id: state.currentGame.id, uci });
}

function formatClock(ms) {
  const safe = Math.max(0, Math.floor(ms));
  const minutes = Math.floor(safe / 60000);
  const seconds = Math.floor((safe % 60000) / 1000);
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function liveClockValues() {
  const game = state.currentGame;
  if (!game) return [0,0];
  let white = game.white_time_ms;
  let black = game.black_time_ms;
  if (game.status === "active") {
    const elapsed = performance.now() - state.clockSnapshotAt;
    if (game.turn === "white") white -= elapsed;
    else black -= elapsed;
  }
  return [Math.max(0, white), Math.max(0, black)];
}

function renderClocks() {
  const game = state.currentGame;
  if (!game || game.status === "waiting") return;
  const [white, black] = liveClockValues();
  const bottomIsWhite = game.viewer_color !== "black";
  const topMs = bottomIsWhite ? black : white;
  const bottomMs = bottomIsWhite ? white : black;
  $("#topClock").textContent = formatClock(topMs);
  $("#bottomClock").textContent = formatClock(bottomMs);
  const topColor = bottomIsWhite ? "black" : "white";
  const bottomColor = bottomIsWhite ? "white" : "black";
  $("#topClock").classList.toggle("active", game.status === "active" && game.turn === topColor);
  $("#bottomClock").classList.toggle("active", game.status === "active" && game.turn === bottomColor);
  $("#topClock").classList.toggle("low", topMs <= 30000 && game.status === "active" && game.turn === topColor);
  $("#bottomClock").classList.toggle("low", bottomMs <= 30000 && game.status === "active" && game.turn === bottomColor);
}

function renderPlayer(container, user, isBottom) {
  const avatar = $(".avatar", container);
  const name = $("b", container);
  const meta = $("small", container);
  avatarStyle(avatar, user || { username: "?" });
  name.textContent = user?.username || "상대 찾는 중";
  meta.textContent = user ? `RATING ${user.rating}${isBottom ? " · YOU" : ""}` : "RATING 100";
}

function renderMoveHistory() {
  const moves = state.currentGame?.moves || [];
  const root = $("#moveHistory");
  if (!moves.length) {
    root.innerHTML = '<div class="empty-state" style="grid-column:1/-1">첫 수를 기다리고 있습니다.</div>';
    return;
  }
  root.innerHTML = "";
  for (let i = 0; i < moves.length; i += 2) {
    const number = document.createElement("div");
    number.className = "move-no";
    number.textContent = `${i / 2 + 1}.`;
    const white = document.createElement("div");
    white.className = "move-san";
    white.textContent = formatUci(moves[i]);
    const black = document.createElement("div");
    black.className = "move-san";
    black.textContent = moves[i + 1] ? formatUci(moves[i + 1]) : "";
    root.append(number, white, black);
  }
  root.scrollTop = root.scrollHeight;
}

function formatUci(move) {
  if (!move) return "";
  const promotion = move[4] ? `=${move[4].toUpperCase()}` : "";
  return `${move.slice(0,2)}–${move.slice(2,4)}${promotion}`;
}

function finishText(game) {
  const myColor = game.viewer_color;
  if (game.result === "1/2-1/2") return ["무승부", "팽팽한 승부였습니다.", "½"];
  const winner = game.result === "1-0" ? "white" : "black";
  const won = winner === myColor;
  const reason = {
    checkmate: "체크메이트",
    resignation: "기권",
    timeout: "시간패",
    stalemate: "스테일메이트",
    draw_agreement: "합의 무승부",
    insufficient_material: "기물 부족",
    threefold_repetition: "3회 반복",
    fifty_moves: "50수 규칙",
  }[game.finish_reason] || "대국 종료";
  return [won ? "승리했습니다" : "패배했습니다", `${reason}로 대국이 끝났습니다.`, won ? "♛" : "♚"];
}

function renderGame() {
  const game = state.currentGame;
  if (!game) return;
  const bottomIsWhite = game.viewer_color !== "black";
  renderPlayer($("#topPlayer"), bottomIsWhite ? game.black : game.white, false);
  renderPlayer($("#bottomPlayer"), bottomIsWhite ? game.white : game.black, true);
  $("#gameRated").textContent = game.rated ? "RATED" : "CASUAL";
  $("#gameStatusText").textContent = game.status === "finished" ? "대국 종료" : game.turn === game.viewer_color ? "당신의 차례" : "상대의 차례";
  renderBoard();
  renderMoveHistory();
  renderClocks();

  const offeredByOpponent = game.draw_offer_by && game.draw_offer_by !== state.user.id;
  $("#drawOffer").classList.toggle("hidden", !offeredByOpponent || game.status !== "active");
  $("#offerDrawBtn").disabled = game.status !== "active";
  $("#resignBtn").disabled = game.status !== "active";

  const overlay = $("#gameOverlay");
  if (game.status === "finished") {
    const [title, text, icon] = finishText(game);
    $("#overlayTitle").textContent = title;
    $("#overlayText").textContent = text;
    $("#overlayIcon").textContent = icon;
    const delta = game.viewer_color === "white" ? game.white_rating_delta : game.black_rating_delta;
    $("#ratingChange").textContent = game.rated ? `${delta >= 0 ? "+" : ""}${delta} RATING` : "친선 대국";
    overlay.classList.remove("hidden");
  } else {
    overlay.classList.add("hidden");
  }
}

async function createRoom() {
  try {
    const data = await api("/api/rooms", { method: "POST", body: JSON.stringify({ rated: true }) });
    hideModal("roomModal");
    state.currentGame = data.game;
    $("#roomCodeDisplay").textContent = data.room_code;
    showModal("roomWaitingModal");
  } catch (error) { toast(error.message, "error"); }
}

async function joinRoom() {
  const code = $("#roomCodeInput").value.trim().toUpperCase();
  if (!code) return toast("방 코드를 입력하세요.", "error");
  try {
    const data = await api(`/api/rooms/${encodeURIComponent(code)}/join`, { method: "POST" });
    hideModal("roomModal");
    setGame(data.game);
  } catch (error) { toast(error.message, "error"); }
}

async function cancelRoom() {
  const game = state.currentGame;
  if (game?.status === "waiting") {
    try { await api(`/api/rooms/${game.id}`, { method: "DELETE" }); } catch (error) { toast(error.message, "error"); }
  }
  state.currentGame = null;
  hideModal("roomWaitingModal");
  navigate("home");
}

async function loadRanking() {
  const root = $("#rankingList");
  root.innerHTML = '<div class="empty-state">순위를 불러오는 중입니다.</div>';
  try {
    const data = await api("/api/leaderboard");
    if (!data.players.length) {
      root.innerHTML = '<div class="empty-state">아직 완료된 레이팅 대국이 없습니다.</div>';
      return;
    }
    root.innerHTML = "";
    data.players.forEach((player, index) => {
      const row = document.createElement("div");
      row.className = "ranking-row";
      row.innerHTML = `
        <span class="rank-no">${String(index + 1).padStart(2, "0")}</span>
        <span class="rank-player"><span class="avatar"></span><span><b></b><small>${tierFor(player.rating)}</small></span></span>
        <span class="rank-record">${player.wins}승 ${player.draws}무 ${player.losses}패</span>
        <span class="rank-rating">${player.rating}</span>`;
      $(".rank-player b", row).textContent = player.username;
      avatarStyle($(".rank-player .avatar", row), player);
      root.appendChild(row);
    });
  } catch (error) {
    root.innerHTML = `<div class="empty-state">${error.message}</div>`;
  }
}

function setupGoogleLogin() {
  if (!state.config?.google_client_id) return;
  $("#googleSection").classList.remove("hidden");
  const render = () => {
    if (!window.google?.accounts?.id) return setTimeout(render, 250);
    google.accounts.id.initialize({
      client_id: state.config.google_client_id,
      callback: async ({ credential }) => {
        try {
          const data = await api("/api/auth/google", { method: "POST", body: JSON.stringify({ credential }) });
          setToken(data.token);
          state.user = data.user;
          renderUser();
          hideModal("accountModal");
          toast("Google 계정에 연결되었습니다.", "success");
          state.socket?.close();
          connectSocket();
        } catch (error) { toast(error.message, "error"); }
      },
    });
    for (const id of ["googleButtonModal", "googleButtonProfile"]) {
      const node = $(`#${id}`);
      if (node) {
        node.innerHTML = "";
        google.accounts.id.renderButton(node, { theme: "filled_black", size: "large", width: node.clientWidth || 320, text: "continue_with" });
      }
    }
  };
  render();
}

async function handleAuthSubmit(endpoint, form) {
  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const result = await api(endpoint, { method: "POST", body: JSON.stringify(data) });
    setToken(result.token);
    state.user = result.user;
    renderUser();
    hideModal("accountModal");
    form.reset();
    toast(endpoint.endsWith("register") ? "계정 연결이 완료되었습니다." : "로그인했습니다.", "success");
    state.socket?.close();
    connectSocket();
  } catch (error) { toast(error.message, "error"); }
}

function bindEvents() {
  $$('[data-nav]').forEach((button) => button.addEventListener("click", () => navigate(button.dataset.nav)));
  $("#userChip").addEventListener("click", () => navigate("profile"));
  $("#quickMatchBtn").addEventListener("click", startQuickMatch);
  $("#openRoomBtn").addEventListener("click", () => showModal("roomModal"));
  $("#createRoomBtn").addEventListener("click", createRoom);
  $("#joinRoomBtn").addEventListener("click", joinRoom);
  $("#roomCodeInput").addEventListener("keydown", (event) => { if (event.key === "Enter") joinRoom(); });
  $("#roomCodeDisplay").addEventListener("click", async () => {
    await navigator.clipboard.writeText($("#roomCodeDisplay").textContent);
    toast("방 코드를 복사했습니다.", "success");
  });
  $("#cancelRoomBtn").addEventListener("click", cancelRoom);
  $("#cancelQueueBtn").addEventListener("click", () => { sendSocket({ type: "queue_leave" }); stopQueueUI(); });
  $("#backLobbyBtn").addEventListener("click", () => { state.currentGame = null; navigate("home"); });
  $("#offerDrawBtn").addEventListener("click", () => sendSocket({ type: "draw_offer", game_id: state.currentGame.id }));
  $("#acceptDrawBtn").addEventListener("click", () => sendSocket({ type: "draw_accept", game_id: state.currentGame.id }));
  $("#resignBtn").addEventListener("click", () => {
    if (confirm("정말 기권하시겠습니까?")) sendSocket({ type: "resign", game_id: state.currentGame.id });
  });
  $("#refreshRankingBtn").addEventListener("click", loadRanking);
  $("#openAccountBtn").addEventListener("click", () => showModal("accountModal"));
  $("#saveProfileBtn").addEventListener("click", async () => {
    try {
      state.user = await api("/api/me", { method: "PATCH", body: JSON.stringify({ username: $("#usernameInput").value }) });
      renderUser();
      toast("닉네임을 저장했습니다.", "success");
    } catch (error) { toast(error.message, "error"); }
  });
  $$('[data-close]').forEach((button) => button.addEventListener("click", () => hideModal(button.dataset.close)));
  $$(".modal-backdrop").forEach((backdrop) => backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop && !["roomWaitingModal", "promotionModal"].includes(backdrop.id)) backdrop.classList.add("hidden");
  }));
  $$('[data-auth-tab]').forEach((button) => button.addEventListener("click", () => {
    $$('[data-auth-tab]').forEach((item) => item.classList.toggle("active", item === button));
    $("#registerForm").classList.toggle("hidden", button.dataset.authTab !== "register");
    $("#loginForm").classList.toggle("hidden", button.dataset.authTab !== "login");
  }));
  $("#registerForm").addEventListener("submit", (event) => { event.preventDefault(); handleAuthSubmit("/api/auth/register", event.currentTarget); });
  $("#loginForm").addEventListener("submit", (event) => { event.preventDefault(); handleAuthSubmit("/api/auth/login", event.currentTarget); });
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      hideModal("roomModal"); hideModal("accountModal");
      state.selectedSquare = null; renderBoard();
    }
  });
}

async function resumeActiveGame() {
  try {
    const data = await api("/api/games/active");
    if (data.game) {
      state.currentGame = data.game;
      if (data.game.status === "waiting") {
        $("#roomCodeDisplay").textContent = data.game.room_code;
        showModal("roomWaitingModal");
      } else {
        setGame(data.game);
      }
    }
  } catch (error) { console.error(error); }
}

async function init() {
  bindEvents();
  try {
    await ensureSession();
    connectSocket();
    await resumeActiveGame();
  } catch (error) {
    toast("서버에 연결하지 못했습니다. 잠시 후 새로고침하세요.", "error");
    console.error(error);
  }
  setInterval(renderClocks, 200);
  setInterval(() => sendSocket({ type: "ping" }), 25000);
}

document.addEventListener("DOMContentLoaded", init);
