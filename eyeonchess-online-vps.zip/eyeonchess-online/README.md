# EyeOnChess Online

접속 즉시 게스트 계정과 **기본 레이팅 100**을 만들고, 실시간 온라인 체스와 Elo 레이팅을 제공하는 VPS용 웹사이트입니다.

## 포함 기능

- 첫 접속 시 Guest 계정 자동 생성, 시작 레이팅 100
- 이메일 회원가입/로그인 및 게스트 기록 승계
- 선택 설정으로 Google 계정 로그인·연동
- WebSocket 기반 실시간 빠른 대전
- 친구 초대용 6자리 방 코드
- 서버 측 합법 수 검증: 체크, 체크메이트, 캐슬링, 앙파상, 승격 포함
- 10분 서버 기준 시계, 시간패·기권·무승부
- 대국 종료 후 Elo 자동 반영, 최저 레이팅 0
- 새로고침·연결 끊김 후 진행 중 대국 복귀
- 실시간 랭킹과 개인 전적
- PostgreSQL 영구 저장, Nginx WebSocket 프록시, Docker Compose 배포

## 1. VPS에서 바로 실행

가장 빠른 방법은 다음 한 줄입니다. 도메인이 있으면 인수로 넣고, 없으면 생략합니다.

```bash
chmod +x setup-vps.sh
./setup-vps.sh chess.example.com
```

스크립트가 `.env`와 긴 임의 비밀키를 자동 생성하고 컨테이너를 실행합니다.

직접 설정하려면 Ubuntu VPS에서 프로젝트 폴더로 이동한 뒤:

```bash
cp .env.example .env
nano .env
```

반드시 아래 두 값을 긴 임의 문자열로 변경합니다.

```env
POSTGRES_PASSWORD=...
JWT_SECRET=...
```

랜덤 비밀키 생성 예시:

```bash
openssl rand -hex 32
```

실행:

```bash
docker compose up -d --build
```

확인:

```bash
docker compose ps
docker compose logs -f api nginx
```

방화벽을 사용한다면:

```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

도메인 없이 먼저 확인할 때는 브라우저에서 `http://VPS_IP`로 접속합니다.

## 2. 도메인과 HTTPS

1. 도메인의 A 레코드를 VPS 공인 IP로 연결합니다.
2. `.env`의 `SITE_DOMAIN`을 실제 도메인으로 바꿉니다.
3. HTTP 상태로 먼저 실행합니다.

```bash
docker compose up -d --build
```

4. 인증서를 발급합니다. 이메일과 도메인을 실제 값으로 바꿉니다.

```bash
docker compose --profile tls run --rm certbot certonly \
  --webroot -w /var/www/certbot \
  --email YOUR_EMAIL@example.com \
  --agree-tos --no-eff-email \
  -d YOUR_DOMAIN.example.com
```

5. Nginx를 다시 만듭니다.

```bash
docker compose up -d --force-recreate nginx
```

이후 `https://도메인`으로 접속합니다.

인증서 갱신:

```bash
docker compose --profile tls run --rm certbot renew
docker compose restart nginx
```

## 3. Google 계정 연동 설정

Google Cloud Console에서 OAuth 2.0 **웹 애플리케이션 클라이언트 ID**를 만든 뒤:

- 승인된 JavaScript 원본: `https://YOUR_DOMAIN`
- `.env`: `GOOGLE_CLIENT_ID=발급받은_클라이언트_ID`

적용:

```bash
docker compose up -d --build api
```

`GOOGLE_CLIENT_ID`를 비워 두면 Google 버튼만 숨겨지고 이메일 계정 기능은 그대로 작동합니다.

## 4. 레이팅 규칙

- 시작 레이팅: `100`
- 기본 K값: `32`
- 계산식: 표준 Elo 기대승률 방식
- 레이팅 하한: `0`

`.env`에서 변경할 수 있습니다.

```env
INITIAL_RATING=100
RATING_K=32
GAME_MINUTES=10
```

## 5. 주요 경로

```text
api/app/main.py          로그인, REST API, WebSocket, 매칭
api/app/game_service.py  수 검증, 시계, 종료 판정, 레이팅 반영
api/app/models.py        사용자·대국 DB 모델
web/index.html           화면 구조
web/styles.css           반응형 디자인
web/app.js               보드, 계정, 매칭, 실시간 통신
deployment/              Docker와 Nginx 설정
```

## 6. 운영상 중요한 점

- API 컨테이너는 현재 **Uvicorn worker 1개**로 실행해야 합니다. 실시간 연결과 매칭 큐가 단일 프로세스 메모리에 있기 때문입니다.
- 한 VPS에서 운영하기에는 충분합니다. 여러 API 서버로 확장할 때는 Redis Pub/Sub과 분산 매칭 큐를 추가해야 합니다.
- DB는 `postgres-data` Docker 볼륨에 저장됩니다. 정기적으로 PostgreSQL 백업을 권장합니다.

백업 예시:

```bash
docker compose exec -T db pg_dump -U eyeonchess eyeonchess > eyeonchess-backup.sql
```

복원 예시:

```bash
cat eyeonchess-backup.sql | docker compose exec -T db psql -U eyeonchess eyeonchess
```

## UI v2 변경 사항

- 녹색/아이보리 기본 체스판과 좌측 메뉴형 온라인 체스 레이아웃
- 브라우저 글꼴에 의존하지 않는 로컬 PNG 체스 기물 12종
- 마지막 수, 선택 칸, 이동 가능 칸, 잡을 수 있는 기물 표시 개선
- 체스판 안쪽 좌표 표시 및 흑 방향 자동 반전
- 모바일/태블릿 반응형 게임 화면
- API 이미지 재빌드 시 필요한 `requests` 의존성 포함

### 기존 VPS를 새 ZIP으로 안전하게 업데이트

기존 `.env`와 PostgreSQL 볼륨은 유지됩니다.

```bash
cd ~
cp eyeonchess-online/.env /tmp/eyeonchess.env
sudo docker compose -f eyeonchess-online/docker-compose.yml down
rm -rf eyeonchess-online
unzip -q -o /tmp/eyeonchess-online-vps.zip -d ~
mv /tmp/eyeonchess.env eyeonchess-online/.env
cd eyeonchess-online
sudo docker compose build --no-cache api web
sudo docker compose up -d
sudo docker compose ps
```
